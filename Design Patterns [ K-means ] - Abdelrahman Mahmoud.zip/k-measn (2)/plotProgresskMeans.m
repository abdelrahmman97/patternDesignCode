function plotProgresskMeans(X, centroids, previous, idx, K, i)
    % Plot the examples
    plotDataPoints(X, idx, K);

    % Plot the centroids as black x's
    plot(centroids(:,1), centroids(:,2), 'x','MarkerEdgeColor','k','MarkerSize', 10, 'LineWidth', 3);

    % Plot the history of the centroids with lines
    for j=1:size(centroids,1)
        drawLine(centroids(j, :), previous(j, :));
    end

    % Title
    title(sprintf('Iteration number %d', i))

end
